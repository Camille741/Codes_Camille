#include"graphe.h"


void AffichageMat(int **mat, int n, int m)
{

 for(int i=0; i< n; i++)
  {
     for (int j=0; j<m; j++)
      {
          printf("%2d ", mat[i][j]);
      }
      printf("\n");
  }
}