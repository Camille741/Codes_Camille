#include<stdio.h>
#include<stdlib.h>


typedef enum 
{
	false,
	true
}Bool;


typedef struct Graphe
{
	int sommets;
	int arcs;
	int **mat_adj;
	int **mat_succ;

}Graphe;

void Affichage(int **mat, int n, int m);
