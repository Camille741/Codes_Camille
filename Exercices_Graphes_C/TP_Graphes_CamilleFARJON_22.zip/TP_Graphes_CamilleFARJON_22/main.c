#include"graphe.h"

int main()
{
    printf("Le fichier est:\n");
    system("cat graphe.txt");
    printf("\n");

    Graphe G;
    G.sommets=3;
    G.arcs;

// Calcul du nombre d'arcs selon le fichier .txt

	FILE*fic =fopen("graphe.txt","r");
    fscanf(fic, "%d", &G.sommets);
	if (fscanf(fic, "%d", &G.sommets) != 1)
    {
        printf("Erreur\n");
        return 1;
    }

int n;
    while ((n = fgetc(fic)) != EOF)
    {
        if (n == '\n')
            G.arcs++;
    }
    G.arcs - 1;


printf("Le graphe possède %d sommets et %d arcs\n",G.sommets,G.arcs);
 

 // --------------------------------------------------------------------  
// Allocation de la matrice d'adj
G.mat_adj = (int**)malloc(G.sommets * sizeof(int*));

for (int i = 0; i < G.sommets; i++)
{
        G.mat_adj[i] = (int*)malloc(G.sommets * sizeof(int*));
 }
 // --------------------------------------------------------------------
 // Calcul de la matrice d'adjacence

 
 rewind(fic);
 // Ignorer la première ligne:
char a;
a= getc(fic);
    while (a!= '\n')
{
    a=getc(fic);
}
    

int b;
int c;


for (int i=0; i<G.arcs; i++)
{
    fscanf(fic, "%d",&b);
    fscanf(fic, "%d",&c);
    b-=1;
    c-=1;
    G.mat_adj[b][c]=1;

}

printf("La matrice d'adjacence est:\n");

Affichage(G.mat_adj,G.sommets,G.sommets);

// Calcul de la place occupée par la matrice
//placeoccupée= nb de cases * sizeof (int)

int D;

    D = (G.sommets*G.sommets)*sizeof(int);


printf("La place occupée par cette matrice est %d bits\n", D);
// --------------------------------------------------------------------
// somme de la matrice au carrée
   /* Je calcule le carré de la matrice pour trouver le nombre de chemins de longueur 2*/
int carre[3][3];
   int i, j, k;

   for (i = 0; i < 3; i++) {
      for (j = 0; j < 3; j++) {
         carre[i][j] = 0;
         for (k = 0; k < 3; k++) {
            carre[i][j] += G.mat_adj[i][k] * G.mat_adj[k][j];
         }
      }
   }
   
int somme;

    for (int i=0; i < G.sommets; i++)
    {
         
             somme =somme+carre[i][i];
            
    
    }
printf("Le nombre de chemin de longueur 2 est %d\n", somme);

 // --------------------------------------------------------------------  
// Allocation de la matrice de successeurs


G.mat_succ = (int**)malloc(G.sommets * sizeof(int*));

for (int i = 0; i < G.sommets; i++)
{
        G.mat_succ[i] = (int*)malloc(G.sommets * sizeof(int*));
 }

// Initialisation de la matrice de successeurs à 0

for(int i=0; i< G.sommets; i++)
 {
     for (int j=0; j<G.sommets+1; j++)
     {
         G.mat_succ[i][j]=0;
         //printf("%2d ", G.mat_succ[i][j]);
     }
     //printf("\n");
 } 
printf("La matrice de successeurs est :\n");
for(int i=0; i<G.sommets; i++)
{
    for(int j=0; j<G.sommets+1; j++)
    {
        if(G.mat_adj[i][j]==1)
        {
            G.mat_succ[i][j+1]=j+1;
            // G.nombre->G.suivant = G.suivant+1
        }
    }
}

int z=1;
for(int j=0;j<G.sommets;j++)
{
    G.mat_succ[j][0]=z;
    z++;
}

for(int i=0; i< G.sommets+1; i++)
 {
     for (int j=0; j<G.sommets+1; j++)
     {
         printf("%2d ", G.mat_succ[i][j]);
     }
     printf("\n");
 } 



    

	return 0;
}