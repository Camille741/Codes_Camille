#include"Library.h"

    Node *createNode(int key)
    {
        Node *newNode = (Node *)malloc(sizeof(Node));
        newNode->key = key;
        return newNode;
    }

    Edge *createEdge(Node *Source, Node *Destination, int weight)
    {
        Edge *newEdge = (Edge *)malloc(sizeof(Edge));
        newEdge->source = Source;
        newEdge->destination = Destination;
        newEdge->weight = weight;
        return newEdge;
    }
/*
    void addNodeToGraph(Graph *graph, Node *node)
    {
        graph->nodes.key= node;
    }

    void addEdgeToGraph(Graph *graph, Edge *edge) 
    {
        graph->edges[weight] = edge;O
    }
    */

    void Affichage(int **mat, int n, int m)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            printf("%2d ", mat[i][j]);
        }
        printf("\n");
    }
}

Graph Nouveau(void) // a changer
{
    Graph G;
    G.numNodes = 0;
    G.numEdges = 0;
    return G;
}


void lecturegraph(Graph G)
{
   
    FILE *fic = fopen("graph.txt", "r");
    G.numNodes =7;
    int n;
    while ((n = fgetc(fic)) != EOF)
    {
        if (n == '\n')
            G.numEdges++;
    }

    printf("Le graphe possède %d sommets et %d arcs\n", G.numNodes, G.numEdges-1);

    // Allocation de la matrice d'adj
    G.mat_adj = (int **)malloc(G.numNodes * sizeof(int *));
    for (int i = 0; i < G.numNodes; i++)
    {
        G.mat_adj[i] = (int *)malloc(G.numNodes * sizeof(int));
        // Initialisation avec des zéros
        memset(G.mat_adj[i], 0, G.numNodes * sizeof(int));
    }


   G.pred = (int **)malloc(G.numNodes * sizeof(int *));
    for (int i = 0; i < G.numNodes; i++) {
        G.pred[i] = (int *)malloc(G.numNodes * sizeof(int));
        for (int j = 0; j < G.numNodes; j++) {
            if (i == j || G.mat_adj[i][j] == INT_MAX) {
                G.pred[i][j] = -1; // Pas de prédécesseur
            } else {
                G.pred[i][j] = i; // Prédécesseur initial
            }
        }
    }
    affichematrice(G);
    floydWarshall(G);
}

void affichematrice(Graph G)
{
    FILE *fic = fopen("graph.txt", "r");

    // Ignorer la première ligne:
    char a;
    while ((a = getc(fic)) != '\n')
    {
    }

    int b, c, d;

    // Lire les données du fichier et mettre à jour la matrice d'adjacence
    while (fscanf(fic, "%d %d %d", &b, &c, &d) == 3)
    {
        G.mat_adj[b][c] = d;

    }

    for(int i=0; i<G.numNodes; i++)
    {
        for(int j=0; j<G.numNodes;j++)
        {
            if (G.mat_adj[i][j]==0)
            {
                G.mat_adj[i][j]= INT_MAX;
            }
        }
    }

    printf("La matrice d'adjacence est:\n");
    Affichage(G.mat_adj, G.numNodes, G.numNodes);
}

void floydWarshall(Graph G)
{
    int dist[G.numNodes][G.numNodes];
    int i, j, k;

    // Initialisation des matrices dist et pred
    for (i = 0; i < G.numNodes; i++) {
        for (j = 0; j < G.numNodes; j++) {
            dist[i][j] = G.mat_adj[i][j];
        }
    }

    // Algorithme de Floyd-Warshall avec mise à jour de la matrice pred
    for (k = 0; k < G.numNodes; k++) {
        for (i = 0; i < G.numNodes; i++) {
            for (j = 0; j < G.numNodes; j++) {
                if (dist[i][k] != INT_MAX && dist[k][j] != INT_MAX && dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                    G.pred[i][j] = G.pred[k][j];
                }
            }
        }
    }

    // Afficher la matrice de distance finale
    printf("Matrice des distances les plus courtes :\n");
    for (i = 0; i < G.numNodes; i++) {
        for (j = 0; j < G.numNodes; j++) {
            if (dist[i][j] == INT_MAX) {
                printf("INF\t");
            } else {
                printf("%d\t", dist[i][j]);
            }
        }
        printf("\n");
    }

    // Afficher la matrice de précédence
    printf("Matrice de précédence :\n");
    for (i = 0; i < G.numNodes; i++) {
        for (j = 0; j < G.numNodes; j++) {
            if (G.pred[i][j] == -1) {
                printf("NIL\t");
            } else {
                printf("%d\t", G.pred[i][j]);
            }
        }
        printf("\n");
    }
}

void printPath(int **pred, int i, int j)
{
    if (i == j) {
        printf("%d ", i);
    } else if (pred[i][j] == -1) {
        printf("Pas de chemin de %d à %d\n", i, j);
    } else {
        printPath(pred, i, pred[i][j]);
        printf("%d ", j);
    }
}

void afficherChemins(Graph G)
{
    printf("Les chemins les plus courts entre chaque paire de sommets :\n");
    for (int i = 0; i < G.numNodes; i++) {
        for (int j = 0; j < G.numNodes; j++) {
            if (i != j) {
                printf("Chemin de %d à %d : ", i, j);
                printPath(G.pred, i, j);
                printf("\n");
            }
        }
    }
}