//matrice d'adjacence pondérée: pas de liaison entre deux sommets -> ajouter la librairie limits.h et insérer le int_max
// question 4 arborescence : mettre la ponderation entre deux sommets


#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include<limits.h>
#include<string.h>


typedef struct Node 
{
     int key; // number of the node        
}Node;


typedef struct Edge
{
    Node *source;  
    Node *destination;
    int weight; 
 
}Edge;

typedef struct Graph {
    int numNodes; //total number of node
    int numEdges; //total number of edges
    Node **nodes;  
    Edge **edges;
    int **mat_adj;
    int **pred; // Matrice de précédence
} Graph;



Node *createNode(int key);
Edge *createEdge(Node *Source, Node *Destination, int weight);
void addNodeToGraph(Graph *graph, Node *node);
 void addEdgeToGraph(Graph *graph, Edge *edge);
  void Affichage(int **mat, int n, int m);
  Graph Nouveau(void);
  void lecturegraph(Graph G);
  void affichematrice(Graph G);
  void floydWarshall(Graph G);
  void printPath(int **pred, int i, int j);
  void afficherChemins(Graph G);

