#include "Library.h"

int main()
{
	
Graph G = Nouveau();
lecturegraph(G);

	return 0;
}