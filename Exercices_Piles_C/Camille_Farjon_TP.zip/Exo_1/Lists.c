#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include"Lists.h"



List *init(void) 
{
    List *L = malloc(sizeof(*L));
    if (L == NULL) 
    {
        exit(EXIT_FAILURE);
    }
    L->first = NULL; // Initialize first to NULL for an empty list
    return L;
}

// Question 3

void Add_employee_first(List *L)
{
    Employee *newbie = malloc(sizeof(*newbie));

    if(L == NULL)
    {
        exit(EXIT_FAILURE);
    }

    newbie->next = L->first;

    printf("Enter the name of your employee:\n");
    scanf("%s",newbie->name);
    printf("Enter the firstname of your employee:\n");
    scanf("%s",newbie->firstname);
    printf("Enter the job of your employee:\n");
    scanf("%s",newbie->job);
     printf("Enter the identification number of your employee:\n");
    scanf("%d",&newbie->id_nb);
    printf("Enter the salary of your employee:\n");
    scanf("%f",&newbie->salary);

    L->first = newbie;
}

// Question 4

void Add_employee_last(List *L) 
    {
    Employee *newbie = malloc(sizeof(*newbie));

    if (newbie == NULL) 
    {
        exit(EXIT_FAILURE);
    }

    newbie->next = NULL;

    if (L->first == NULL) 
    {
        printf("Enter the name of your employee (do not put any space):\n");
        scanf("%s", newbie->name);
        printf("Enter the firstname of your employee (do not add any space):\n");
        scanf("%s", newbie->firstname);
        printf("Enter the job of your employee:\n");
        scanf("%s", newbie->job);
        printf("Enter the identification number of your employee:\n");
        scanf("%d", &newbie->id_nb);
        printf("Enter the salary of your employee:\n");
        scanf("%f", &newbie->salary);

        L->first = newbie;
    } 
    else
    {
        Employee *temp = L->first;
        while (temp->next != NULL) 
        {
            temp = temp->next;
        }

        printf("Enter the name of your employee (do not put any space):\n");
        scanf("%s", newbie->name);
        printf("Enter the firstname of your employee (do not add any space):\n");
        scanf("%s", newbie->firstname);
        printf("Enter the job of your employee:\n");
        scanf("%s", newbie->job);
        printf("Enter the identification number of your employee:\n");
        scanf("%d", &newbie->id_nb);
        printf("Enter the salary of your employee:\n");
        scanf("%f", &newbie->salary);

        temp->next = newbie;
    }
}


// Question 5

void Erase_employee_first(List *L)
{
    if (L == NULL)
    {
        exit(EXIT_FAILURE);
    }

 
        Employee *fired = L->first;
        L->first = L->first->next;
        free(fired);
}


// Question 6

void Erase_employee_last(List *L)
{
    if (L == NULL)
    {
        exit(EXIT_FAILURE);
    }

     while (L->first != NULL)
    {
            L->first = L->first->next;
    }
 
        Employee *fired = L->first;
        L->first = L->first->next;
        free(fired);
}

//Question 7

void Print_list(List *L)
 {
    Employee *actual_e = L->first;
    while (actual_e != NULL) 
    {
        printf("Name: %s\n", actual_e->name);
        printf("Firstname: %s\n", actual_e->firstname);
        printf("Identification number: %d\n", actual_e->id_nb);
        printf("Job: %s\n", actual_e->job);
        printf("Salary: %f\n", actual_e->salary);
        actual_e = actual_e->next;
    }
}



// Question 8

int Mirror (List * L) 
{
    Employee *prev = NULL;
    Employee *current = L->first;
    Employee *next = NULL;

    while (current != NULL) 
    {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }

    L->first = prev;
    return 0;
}


// Question 9

int Update_salary(List*L)
{
    char tmp[25];
    //strcmp
    printf("Enter the name of the employee you want to update the salary of: \n");
    scanf("%s",tmp);
    while(L->first != NULL)
    {
            
    int result = strcmp(L->first->name, tmp);
    while(result != 0)
        {
                L->first = L->first->next ;
        }
        printf("Enter the new salary of %s\n", L->first->name);
        scanf("%f", &L->first->salary);

        if (L->first->salary <= 0)
        {
            printf("ERROR");
            Update_salary(L);
        }
        return 0;
    }
    

}

//Question 10

void Range_List_by_Salaries(List *L)
    {
    if (L == NULL || L->first == NULL || L->first->next == NULL)
    {
        return; 
    }

    int swapped;
    Employee *current;
    Employee *last = NULL;

    do 
    {
        swapped = 0;
        current = L->first;

        while (current->next != last && current->next != NULL) 
        {
            if (current->salary > current->next->salary) 
            {
                Employee *tmp = current->next;
                current->next = tmp->next;
                tmp->next = current;

                if (last == NULL)
                {
                    L->first = tmp;
                } 
                else 
                {
                    last->next = tmp;
                }

                last = tmp;
                swapped = 1;
            } 
            else 
            {
                if (last == NULL) 
                {
                    last = current;
                } 
                else 
                {
                    last = last->next;
                }
                current = current->next;
            }
        }
    } 
    while (swapped);
}


//Question 11

void displayEmployeesByService(List *L, const char *service) 
{
    Employee *current = L->first;

    while (current->name != NULL) 
    {
        if (strcmp(current->job, service) == 0) 
        {
            printf("Name: %s %s\n", current->firstname, current->name);
            printf("ID: %d\n", current->id_nb);
            printf("Job: %s\n", current->job);
            printf("Salary: %.2f\n", current->salary);
            printf("\n");
        }
        current = current->next;
    }
}

// Question 13

float all_salaries(Employee *e) 
{
    if (e == NULL) 
    {
        return 0; 
    } 
    else
    {
        return e->salary + all_salaries(e->next);
    }
}




void menu(List *L) 
{
    int choice;
    char service[25]; 

    do 
    {

        printf("Choose an option:\n");
        printf("(1) See the list of the employees.\n");
        printf("(2) Add an employee at the head of the list.\n");
        printf("(3) Add an employee at the end of the list\n");
        printf("(4) Erase an employee at the head of the list.\n");
        printf("(5) Erase an employee at the end of the list.\n");
        printf("(6) Update the salary of an employee\n");
        printf("(7) Range the list by salaries.\n");
        printf("(8) Search all the employees of a service.\n");
        printf("(9) Print the total of all  salaries.\n");
        printf("(10) Put the list in mirrored.\n");
        printf("(11) Exit.\n"); // Option de sortie

        scanf("%d", &choice);

        switch (choice) 
        {
            case 1:
                Print_list(L);
                menu(L);
                break;
            case 2:
                Add_employee_first(L);
                menu(L);
                break;

            case 3:
            Add_employee_last(L);
            menu(L);
            break;

            case 4:
            Erase_employee_first(L);
            menu(L);
            break;

            case 5:
            Erase_employee_last(L);
            menu(L);
            break;

            case 6:
            Update_salary(L);
            menu(L);
            break;

            case 7:
            Range_List_by_Salaries(L);
            menu(L);
            break;

            case 8:
                printf("Enter a service\n");
                scanf("%s", service); 
                displayEmployeesByService(L, service);
                menu(L);
                break;

            case 9:
                float totalSalaries = all_salaries(L->first); 
                printf("Total salaries: %.2f\n", totalSalaries);
                menu(L);
                break;

            case 10:
                Mirror(L);
                menu(L);
                break;

            case 11:
                break;


            default:
                printf("Invalid choice.\n");
                menu(L);
                break;
        }
    } 
    while (choice != 9); 
}
