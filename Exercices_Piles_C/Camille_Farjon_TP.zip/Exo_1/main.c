#include"Lists.h"



int main ()
{
    List *L = init();
   menu(L);

    return 0;
}