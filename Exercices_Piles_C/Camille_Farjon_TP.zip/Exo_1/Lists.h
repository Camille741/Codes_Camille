#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

typedef struct Employee Employee; // cell of a single employee
struct Employee
{
     char name[25];
     char firstname[25];
     int id_nb;
     char job[25];
     float salary;
    Employee *next;
};

typedef struct 
{
    Employee * first;
    int nb_elements;        
}List;



List *init(void);
void Add_employee_first(List *L);
void Add_employee_last(List *L) ;
void Erase_employee_first(List *L);
void Erase_employee_last(List *L);
void Print_list(List *L);
int Mirror (List * L) ;
int Update_salary(List*L);
void Range_List_by_Salaries(List *L);
void displayEmployeesByService(List *L, const char *service);
float all_salaries(Employee *e);
void menu(List *L);