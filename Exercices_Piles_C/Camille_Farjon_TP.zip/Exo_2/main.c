#include"Piles.h"

int main()
{

    Pile *P = Init_pile();
    Pile *P2 = Init_pile();

    empiler(P2,7);
    empiler (P2, 14);
    empiler(P2,3);
    menu(P,P2);

    return 0;
}