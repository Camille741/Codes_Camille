#include"Piles.h"


Pile * Init_pile(void)
{
    Pile * P;
    P= malloc(sizeof(*P));

    for (int i=0; i<25; i++)
    {
        P->Tab[i]=0;
    }
    P->sommet=0;

    return P;
}

bool is_empty(Pile * P)
{
        if(P->sommet == 0 || P->sommet == -1)
            return 1;

        return 0;
}


bool is_full(Pile * P)
{
        if(P->Tab[25] == P->sommet )
            return 1;

        return 0;
}


void empiler(Pile *pile, int element)
 {
    if (pile->sommet < 25) 
    {
        pile->Tab[pile->sommet] = element;
        (pile->sommet)++;
       
    } 
}

int depiler(Pile *pile) 
{
    if (pile->sommet > 0)
    {
        (pile->sommet)--; 
        return pile->Tab[pile->sommet];
    } 
    else 
    {
        printf("La pile est vide, impossible de depiler.\n");
        return -1; 
    }
}

void Print_pile(Pile *P) 
{
    int i = 0;


    while (i < P->sommet) {
            printf("%d \n", P->Tab[i]);
            i++;
    }
}

int sommetPile(Pile *pile) 
{
    if (pile->sommet > 0) 
    { 
        return pile->Tab[pile->sommet - 1]; 
    } 
    else
    {
        printf("La pile est vide, aucun sommet disponible.\n");
        return -1; 
}
}

void alternerPiles(Pile *P, Pile *P2) 
{
    Pile*P3=Init_pile();
    printf("Les deux piles sont\n");
    Print_pile(P);
    printf("\net\n");
    Print_pile(P2);

   int i=0;
   int j=0;

    while (P->Tab[i] != 0 || P2->Tab[j] != 0)
        {
        empiler(P3,P->Tab[i]);
        empiler(P3, P2->Tab[j]);
        i++;
        j++;
        }
printf("La pile alternée est\n");
Print_pile(P3);
printf("\n");
}





void menu(Pile *P, Pile *P2)
{

    
    printf("1 - Empiler\n2 - Depiler\n3 - Afficher la pile\n");
    printf("4 - Alterner deux piles\n5 - Afficher le sommet de la pile\n");
    printf("6 - Afficher si la pile est vide ou non\n");
    printf("7 - Afficher si la pile est pleine ou non\n");
    printf("8 - Quitter le programme\n");
    int choice;
    scanf("%d",&choice);

    switch (choice) 
        {
            case 1:
                printf("Choisissez un nombre à mettre dans la pile\n");
                int e;
                scanf("%d",&e);
                empiler(P,e);
                menu(P,P2);
                break;
            case 2:
                depiler(P);
                menu(P,P2);
                break;

            case 3:
            printf("La pile actuelle est:\n");
            Print_pile(P);
            menu(P,P2);
            break;

           case 4 :
            alternerPiles(P,P2);
            menu(P,P2);
            
            break;

        case 5:
            printf("Le sommet de la pile est :%d\n",sommetPile(P));
            menu(P,P2);
            break;

        case 6:
            if(is_empty(P)==1)
                printf("La pile est vide\n");
            if(is_empty(P)==0)
                printf("La pile n'est pas vide\n");

            menu(P,P2);
            break;

        case 7: 
            if(is_full(P)==1)
                printf("La pile est pleine\n");
            if(is_full(P)==0)
                printf("La pile n'est pas pleine\n");

            menu(P,P2);
            break;

        case 8 :
            break;


        default:
            break;
        }
}