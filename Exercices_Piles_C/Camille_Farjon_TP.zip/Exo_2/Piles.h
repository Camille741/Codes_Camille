#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>


typedef struct
{
    int sommet;
    int Tab[25];

}Pile;

Pile * Init_pile(void);
bool is_empty(Pile * P);
bool is_full(Pile * P);
void empiler(Pile *pile, int element);
int depiler(Pile *pile);
void Print_pile(Pile *P) ;
int sommetPile(Pile *pile) ;
void alternerPiles(Pile *P, Pile *P2);
void menu(Pile *P, Pile *P2);