#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>

#define CREATION_FAILURE -1
#define FATAL_FAILURE -2
#define DISPLAY_PREFIX



typedef struct Tree
{
    int iValue;
    struct Tree* TreeLeft;
    struct Tree* TreeRight;
    struct Tree* TreeParent;
}Tree;



Tree* createTreeWithValue(int e);
Tree* createTreeWithTreeAndValue(int e, Tree* TLeft, Tree* TRight);
void freeTreeMemory(Tree* T);
Tree* TabToTree();
void displayTree(Tree* T);
int countLeftTreeNode(Tree* T);
int getHeight(Tree* root);
bool areTreesEqual(Tree* root1, Tree* root2);
void printLevel(Tree* root, int level);
void printPrefix(Tree* root);
void breadthFirstTraversal(Tree* root);