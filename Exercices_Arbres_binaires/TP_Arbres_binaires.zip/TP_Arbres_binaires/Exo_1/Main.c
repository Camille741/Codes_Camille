#include"Library.h"

int main ()
{
    //-------------
    //Test part
    Tree* TreeTmp = createTreeWithTreeAndValue(6,createTreeWithTreeAndValue(2,createTreeWithValue(8), createTreeWithValue(3)),createTreeWithValue(4));

    displayTree(TreeTmp);
    printf("La hauteur de l'arbre est:%d\n", getHeight(TreeTmp));
    printf("La somme des valeurs du sous arbre gauche de l'arbre est %d\n", countLeftTreeNode(TreeTmp)-TreeTmp->iValue);
    freeTreeMemory(TreeTmp);



    Tree *T = TabToTree();
   displayTree(T);

   
   free(T);
    return 0;
}