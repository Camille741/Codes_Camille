#include"Library.h"


// Question 1

Tree* createTreeWithValue(int e)
{
     Tree* TreeTmp = malloc(sizeof(*TreeTmp));

    if(TreeTmp == NULL)
    {
        printf("FATAL ERROR] - Error on alllocation for creating Tree\n");
        exit(CREATION_FAILURE);
    }

    TreeTmp->iValue = e;
    TreeTmp->TreeLeft = NULL;
    TreeTmp->TreeRight = NULL;
    TreeTmp->TreeParent = NULL;

    return TreeTmp;
}




// Question 2

Tree* createTreeWithTreeAndValue(int e, Tree* TLeft, Tree* TRight)
{
   Tree* TreeTmp = malloc (sizeof(*TreeTmp));

    if(TreeTmp == NULL)
    {
        printf("FATAL ERROR] - Error on alllocation for creating Tree\n");
        exit(CREATION_FAILURE);       
    }

    TreeTmp->iValue = e;
    TreeTmp->TreeLeft = TLeft;
    TreeTmp->TreeRight = TRight;

    if(TLeft != NULL)
        TLeft->TreeParent = TreeTmp;
    if(TRight != NULL)
        TRight->TreeParent = TreeTmp;

    return TreeTmp;
}

// Question 3
void freeTreeMemory(Tree* T)
{
    if (T == NULL)
        return;

    //Recursive call to free memory on childs
    freeTreeMemory(T->TreeLeft);
    freeTreeMemory(T->TreeRight);

    printf("Free memory for Node : %d\n",T->iValue);
    free(T);
}


// Question 5

Tree* TabToTree()
{
    int Tab[7] = {3, 22, 20, 0, 0, 15, 7};
    printf("The current tab is : ");

    for (int j=0; j<7;j++)
    {
        printf(" %d ", Tab[j]);
    }
    printf("\n");

    Tree* root = createTreeWithValue(Tab[0]); // Création du nœud racine
    Tree* currentNode = root;

    for (int i = 1; i < 7; i++)
    {
        if (currentNode->TreeLeft == NULL) {
            currentNode->TreeLeft = createTreeWithValue(Tab[i]);
            currentNode->TreeLeft->TreeParent = currentNode;
            currentNode = currentNode->TreeLeft;
        }
        else if (currentNode->TreeRight == NULL) {
            currentNode->TreeRight = createTreeWithValue(Tab[i]);
            currentNode->TreeRight->TreeParent = currentNode;
            currentNode = currentNode->TreeRight; 
        }
        else
        {
           
            while (currentNode->TreeLeft != NULL && currentNode->TreeRight != NULL && currentNode != root)
            {
                currentNode = currentNode->TreeParent;
            }

            

            if (currentNode == root && currentNode->TreeLeft != NULL && currentNode->TreeRight != NULL)
            {
                break;
            }

          

            if (currentNode->TreeLeft == NULL)
            {
                currentNode->TreeLeft = createTreeWithValue(Tab[i]);
                currentNode->TreeLeft->TreeParent = currentNode;
                currentNode = currentNode->TreeLeft; // Déplacer le nœud actuel vers le nouvel enfant gauche
            }
            else
            {
                currentNode->TreeRight = createTreeWithValue(Tab[i]);
                currentNode->TreeRight->TreeParent = currentNode;
                currentNode = currentNode->TreeRight; // Déplacer le nœud actuel vers le nouvel enfant droit
            }
        }
    }

    return root;
}



void displayTree(Tree* T)
{
    if (T == NULL)
        return;

    if(T->TreeParent != NULL)
        printf("(%d) -> (%d)\n", T->TreeParent->iValue, T->iValue);
    else
        printf("(%d)\n",T->iValue);

    #ifdef DISPLAY_POSTFIX
    if(T->TreeRight != NULL)
        displayTree(T->TreeRight);
    if(T->TreeLeft != NULL)
        displayTree(T->TreeLeft);
    #endif

    #ifdef DISPLAY_PREFIX
    if(T->TreeLeft != NULL)
        displayTree(T->TreeLeft);
    if(T->TreeRight != NULL)
        displayTree(T->TreeRight);
    #endif
}

// Question 6

int countLeftTreeNode(Tree* T)
{
    if(T == NULL)
    {
        return 0;
    }

    return T->iValue + (countLeftTreeNode(T->TreeLeft));  
}

// Question 7

int getHeight(Tree* root)
{
    if (root == NULL)
        return 0;
    else {
        int leftHeight = getHeight(root->TreeLeft);
        int rightHeight = getHeight(root->TreeRight);

        if (leftHeight > rightHeight)
            return (leftHeight + 1);
        else
            return (rightHeight + 1);
    }
}

// Question 8

bool areTreesEqual(Tree* root1, Tree* root2)
{
    if (root1 == NULL && root2 == NULL)
        return true;
 
    if (root1 == NULL || root2 == NULL)
        return false;
 
    if (root1->iValue != root2->iValue)
        return false;
 
    return areTreesEqual(root1->TreeLeft, root2->TreeLeft) && areTreesEqual(root1->TreeRight, root2->TreeRight);
}



// Fonction pour imprimer un niveau de l'arbre
void printLevel(Tree* root, int level)
{
    if (root == NULL)
        return;
    if (level == 1)
        printf("%d ", root->iValue); 
    else if (level > 1) {
        printLevel(root->TreeLeft, level - 1);
        printLevel(root->TreeRight, level - 1);
    }
}

// Question 9

void printPrefix(Tree* root)
{
    if (root != NULL)
    {
        printf("%d ", root->iValue);
        printPrefix(root->TreeLeft);
        printPrefix(root->TreeRight);
    }
}


// Parcours en largeur de l'arbre binaire

// Question 10
void breadthFirstTraversal(Tree* root)
{
    int height = getHeight(root);
    for (int i = 1; i <= height; i++)
        printLevel(root, i);
}






