#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>

#define CREATION_FAILURE -1
#define FATAL_FAILURE -2
#define DISPLAY_PREFIX



typedef struct Tree
{
    int iValue;
    struct Tree* TreeLeft;
    struct Tree* TreeRight;
    struct Tree* TreeParent;
}Tree;




Tree* createTreeWithValue(int e)
{
     Tree* TreeTmp = malloc(sizeof(*TreeTmp));

    if(TreeTmp == NULL)
    {
        printf("FATAL ERROR] - Error on alllocation for creating Tree\n");
        exit(CREATION_FAILURE);
    }

    TreeTmp->iValue = e;
    TreeTmp->TreeLeft = NULL;
    TreeTmp->TreeRight = NULL;
    TreeTmp->TreeParent = NULL;

    return TreeTmp;
}

void freeTreeMemory(Tree* T)
{
    if (T == NULL)
        return;

    //Recursive call to free memory on childs
    freeTreeMemory(T->TreeLeft);
    freeTreeMemory(T->TreeRight);

    printf("Free memory for Node : %d\n",T->iValue);
    free(T);
}

Tree* createTreeWithTreeAndValue(int e, Tree* TLeft, Tree* TRight)
{
   Tree* TreeTmp = malloc (sizeof(*TreeTmp));

    if(TreeTmp == NULL)
    {
        printf("FATAL ERROR] - Error on alllocation for creating Tree\n");
        exit(CREATION_FAILURE);       
    }

    TreeTmp->iValue = e;
    TreeTmp->TreeLeft = TLeft;
    TreeTmp->TreeRight = TRight;

    if(TLeft != NULL)
        TLeft->TreeParent = TreeTmp;
    if(TRight != NULL)
        TRight->TreeParent = TreeTmp;

    return TreeTmp;
}


Tree* TabToTree(Tree* T)
{
    int Tab[7] = {3, 22, 20, 0, 0, 15, 7};

    Tree* root = createTreeWithValue(Tab[0]);
    Tree* currentNode = root;

    for (int i = 1; i < 7; i++) {
        if (currentNode->TreeLeft == NULL) {
            currentNode->TreeLeft = createTreeWithValue(Tab[i]);
            currentNode->TreeLeft->TreeParent = currentNode;
        }
         else if (currentNode->TreeRight == NULL) 
        {
            currentNode->TreeRight = createTreeWithValue(Tab[i]);
            currentNode->TreeRight->TreeParent = currentNode;
        } 
        else 
        {
            while (currentNode->TreeLeft != NULL && currentNode->TreeRight != NULL) 
            {
                currentNode = currentNode->TreeParent;
            }
            if (currentNode->TreeLeft == NULL) 
            {
                currentNode->TreeLeft = createTreeWithValue(Tab[i]);
                currentNode->TreeLeft->TreeParent = currentNode;
            } 
            else 
            {
                currentNode->TreeRight = createTreeWithValue(Tab[i]);
                currentNode->TreeRight->TreeParent = currentNode;
            }
        }
    }

    return root;
}



void displayTree(Tree* T)
{
    if (T == NULL)
        return;

    if(T->TreeParent != NULL)
        printf("(%d) -> (%d)\n", T->TreeParent->iValue, T->iValue);
    else
        printf("(%d)\n",T->iValue);

    #ifdef DISPLAY_POSTFIX
    if(T->TreeRight != NULL)
        displayTree(T->TreeRight);
    if(T->TreeLeft != NULL)
        displayTree(T->TreeLeft);
    #endif

    #ifdef DISPLAY_PREFIX
    if(T->TreeLeft != NULL)
        displayTree(T->TreeLeft);
    if(T->TreeRight != NULL)
        displayTree(T->TreeRight);
    #endif
}


int countTreeNodeWithRootAndLeaf(Tree* T)
{
    if(T == NULL)
        return 0;

    return(countTreeNodeWithRootAndLeaf(T->TreeLeft)+ countTreeNodeWithRootAndLeaf(T->TreeRight)+ 1);  //1 to add the root itself
}


bool areTreesEqual(Tree* root1, Tree* root2)
{
    if (root1 == NULL && root2 == NULL)
        return true;
 
    if (root1 == NULL || root2 == NULL)
        return false;
 
    if (root1->iValue != root2->iValue)
        return false;
 
    return areTreesEqual(root1->TreeLeft, root2->TreeLeft) && areTreesEqual(root1->TreeRight, root2->TreeRight);
}


// Fonction pour obtenir la hauteur de l'arbre
int getHeight(Tree* root)
{
    if (root == NULL)
        return 0;
    else {
        int leftHeight = getHeight(root->TreeLeft);
        int rightHeight = getHeight(root->TreeRight);

        if (leftHeight > rightHeight)
            return (leftHeight + 1);
        else
            return (rightHeight + 1);
    }
}

// Fonction pour imprimer un niveau de l'arbre
void printLevel(Tree* root, int level)
{
    if (root == NULL)
        return;
    if (level == 1)
        printf("%d ", root->iValue); // Modification pour afficher la valeur de iValue au lieu de data
    else if (level > 1) {
        printLevel(root->TreeLeft, level - 1);
        printLevel(root->TreeRight, level - 1);
    }
}


// Parcours en largeur de l'arbre binaire


void breadthFirstTraversal(Tree* root)
{
    int height = getHeight(root);
    for (int i = 1; i <= height; i++)
        printLevel(root, i);
}






int main ()
{
    //-------------
    //Test part
    Tree* TreeTmp = createTreeWithTreeAndValue(6,createTreeWithTreeAndValue(2,createTreeWithValue(8), createTreeWithValue(3)),createTreeWithValue(4));

    displayTree(TreeTmp);
    freeTreeMemory(TreeTmp);

    return 0;
}