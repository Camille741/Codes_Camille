#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

//-------------------------------
// Binary tree and 
// Binary search tree (BST)
//-------------------------------

//-------------------------------
// Defines
//-------------------------------
#define CREATION_FAILURE -1
#define FATAL_FAILURE -2
#define DISPLAY_PREFIX
//#define DISPLAY_POSTFIX

//-------------------------------
// Structures
//-------------------------------
typedef struct binaryTree tree;
typedef struct binaryNode node;

struct binaryTree
{
    int iValue;
    tree* treeLeft;
    tree* treeRight;
    tree* treeParent;
}binaryTree;

struct binaryNode
{
    char data;             // Opérateur (+, -, *, /) ou opérande
    node* left;     // Pointeur vers le sous-arbre gauche
    node* right;    // Pointeur vers le sous-arbre droit
}binaryNode;

//-------------------------------
// Prototype
//-------------------------------
tree* createTreeWithValue(int _iValue);
void freeTreeMemory(tree* _tree);
tree* createTreeWithTreeAndValue(int _iValue, tree* _treeLeft, tree* _treeRight);
void displayTree(tree* _tree);
int countTreeNodeWithRootAndLeaf(tree* _tree);
tree* recursiveInsertInTree(tree* _root,tree* _parentTree, int _iValue);
tree* recursiveRemove(tree* _root, int _iValue);
tree* findMinimum(tree* _root);
tree* findMaximum(tree* _root);
bool isBST(tree* _root); 
bool isComplete(tree* _root, int _iIndex, int _iNbNode);
node* createNode(char value);
int evaluateExpression(node* _root);
void goToExerciceTwo(void);

//-------------------------------
// Main
//-------------------------------
int main (void)
{
    //-------------
    //Test part
    tree* treeTmp = createTreeWithTreeAndValue(6,
        createTreeWithTreeAndValue(2,createTreeWithValue(8), createTreeWithValue(3)),
        createTreeWithValue(4)
        );

    displayTree(treeTmp);

    tree* treeInsert = recursiveInsertInTree(treeTmp,NULL,12);

    displayTree(treeInsert);

    bool bReturn = isBST(treeInsert);
    printf("\nisBST return : %d\n", bReturn);

    bReturn = isComplete(treeInsert,0,countTreeNodeWithRootAndLeaf(treeInsert));
    printf("\nisComplete return : %d\n", bReturn);

    freeTreeMemory(treeTmp);

    goToExerciceTwo();

    return 0;
}

//-------------------------------
// Functions and procedures
//-------------------------------
tree* createTreeWithValue(int _iValue)
{
    tree* treeTmp = malloc(sizeof(*treeTmp));

    if(treeTmp == NULL)
    {
        printf("FATAL ERROR] - Error on alllocation for creating tree\n");
        exit(CREATION_FAILURE);
    }

    treeTmp->iValue = _iValue;
    treeTmp->treeLeft = NULL;
    treeTmp->treeRight = NULL;
    treeTmp->treeParent = NULL;

    return treeTmp;
}

void freeTreeMemory(tree* _tree)
{
    if (_tree == NULL)
        return;

    //Recursive call to free memory on childs
    freeTreeMemory(_tree->treeLeft);
    freeTreeMemory(_tree->treeRight);

    printf("Free memory for node : %d\n",_tree->iValue);
    free(_tree);
}

tree* createTreeWithTreeAndValue(int _iValue, tree* _treeLeft, tree* _treeRight)
{
    tree* treeTmp = malloc (sizeof(*treeTmp));

    if(treeTmp == NULL)
    {
        printf("FATAL ERROR] - Error on alllocation for creating tree\n");
        exit(CREATION_FAILURE);       
    }

    treeTmp->iValue = _iValue;
    treeTmp->treeLeft = _treeLeft;
    treeTmp->treeRight = _treeRight;

    if(_treeLeft != NULL)
        _treeLeft->treeParent = treeTmp;
    if(_treeRight != NULL)
        _treeRight->treeParent = treeTmp;

    return treeTmp;
}

//----------------------------------------------------
//Function can display in prefix or postfix mode by
//uncomment the appropriate define
//----------------------------------------------------
void displayTree(tree* _tree)
{
    if (_tree == NULL)
        return;

    if(_tree->treeParent != NULL)
        printf("(%d) -> (%d)\n", _tree->treeParent->iValue, _tree->iValue);
    else
        printf("(%d)\n",_tree->iValue);

    #ifdef DISPLAY_POSTFIX
    if(_tree->treeRight != NULL)
        displayTree(_tree->treeRight);
    if(_tree->treeLeft != NULL)
        displayTree(_tree->treeLeft);
    #endif

    #ifdef DISPLAY_PREFIX
    if(_tree->treeLeft != NULL)
        displayTree(_tree->treeLeft);
    if(_tree->treeRight != NULL)
        displayTree(_tree->treeRight);
    #endif
}

//----------------------------------------------------
//Function count each note including the root node
//and the leafs of the tree.
//----------------------------------------------------
int countTreeNodeWithRootAndLeaf(tree* _tree)
{
    if(_tree == NULL)
        return 0;

    return(countTreeNodeWithRootAndLeaf(_tree->treeLeft)+
           countTreeNodeWithRootAndLeaf(_tree->treeRight)+
           1);  //1 to add the root itself
}

//----------------------------------------------------
//Function received the root node and the value of
//the next node to insert.
//We perform it recusrively for best performance.
//----------------------------------------------------
tree* recursiveInsertInTree(tree* _root,tree* _parentTree, int _iValue)
{
    if(_root == NULL)
    {
        tree* treeTmp =  createTreeWithValue(_iValue);
        treeTmp->treeParent = _parentTree;
        return treeTmp;
    }
        

    if(_root->iValue < _iValue)
        _root->treeRight = recursiveInsertInTree(_root->treeRight,_root,_iValue);
    else if(_root->iValue > _iValue)
        _root->treeLeft = recursiveInsertInTree(_root->treeLeft,_root, _iValue);

    return _root;
}

//----------------------------------------------------
// Function to remove a specific node by its value
// Function is recursive for performance.
//----------------------------------------------------
tree* recursiveRemove(tree* _root, int _iValue)
{
    if(_root == NULL) //_iValue is not in tree
        return _root;
    else if(_iValue < _root->iValue) //find the node in left or right part
        _root->treeLeft = recursiveRemove(_root->treeLeft, _iValue);
    else if(_iValue > _root->iValue)
        _root->treeRight = recursiveRemove(_root->treeRight,_iValue);
    else
    {
        //We find the node to remove. Make some check
        //Check if the node is a leaf
        if(_root->treeLeft == NULL && _root->treeRight == NULL)
        {
            free(_root);
            _root = NULL;
        }
        else if(_root->treeLeft == NULL)    //One child only
        {
            tree* treeTmp = _root;
            _root = _root->treeRight; 
            free(treeTmp);
        }
        else if(_root->treeRight == NULL)   //Idem
        {
            tree* treeTmp = _root;
            _root = _root->treeLeft;
            free(treeTmp);
        }
        else
        {
            //In this case we have more or one child and/or hierarchy
            tree* treeTmp = findMinimum(_root->treeRight);
            _root->iValue = treeTmp->iValue;
            _root->treeParent = treeTmp->treeParent;
            _root->treeRight = recursiveRemove(_root->treeRight,treeTmp->iValue);
        }
    }

    return _root;
}

//----------------------------------------------------
// find minimum and maximum value in a tree
// Functions are recursive for performance.
//----------------------------------------------------
tree* findMinimum(tree* _root)
{
    if(_root == NULL)
        return _root;
    else if(_root->treeLeft == NULL)
        return _root;
    else
        return findMinimum(_root->treeLeft);
}

tree* findMaximum(tree* _root)
{
    if(_root == NULL)
        return _root;
    else if(_root->treeRight == NULL)
        return _root;
    else
        return findMaximum(_root->treeRight);
}

//----------------------------------------------------
//Function to test if a tree is a binary search tree
//or not
//----------------------------------------------------
bool isBST(tree* _root)
{
    if(_root == NULL)
        return true;

    if(_root->treeLeft == NULL && _root->treeRight == NULL)
        return true;

    if(_root->treeRight == NULL)
        return _root->treeLeft->iValue <= _root->iValue && isBST(_root->treeLeft);

    if(_root->treeLeft == NULL)
        return _root->treeRight->iValue <= _root->iValue && isBST(_root->treeRight);

    return _root->treeLeft->iValue <= _root->iValue
            && _root->treeRight->iValue > _root->iValue
            && isBST(_root->treeLeft)
            && isBST(_root->treeRight);
}

//----------------------------------------------------
//Function to test if a tree is a complete binary tree
//----------------------------------------------------
bool isComplete(tree* _root, int _iIndex, int _iNbNode)
{
    if(_root == NULL)
        return true;

    if(_iIndex >= _iNbNode)
        return false;

    return(isComplete(_root->treeLeft,2*_iIndex+1,_iNbNode)
           && isComplete(_root->treeRight,2*_iIndex+2,_iNbNode));
}

//----------------------------------------------------
// Function to create a single node
//----------------------------------------------------
node* createNode(char value)
{
    node* nodeTmp = malloc(sizeof(node));
    nodeTmp->data = value;
    nodeTmp->left = nodeTmp->right = NULL;
    return nodeTmp;
}

//----------------------------------------------------
// Function to evaluate the expression
//----------------------------------------------------
int evaluateExpression(node* _root) 
{
    // if the node is a leaf (opérande)
    if (_root->left == NULL && _root->right == NULL)
    {
        // convert the char to integer value
        return _root->data - '0'; 
    }

    // evaluate right and left sub tree recursively
    int leftValue = evaluateExpression(_root->left);
    int rightValue = evaluateExpression(_root->right);

    // Apply the operator to the sub tree result
    switch (_root->data)
    {
        case '+':
            return leftValue + rightValue;
        case '-':
            return leftValue - rightValue;
        case '*':
            return leftValue * rightValue;
        case '/':
            if (rightValue != 0)
            {
                return leftValue / rightValue;
            } 
            else
            {
                printf(" [FATAL ERROR] - Division by 0.\n");
                exit(FATAL_FAILURE);
            }
        default:
            printf(" [FATAL ERROR] - Operation not valid.\n");
            exit(FATAL_FAILURE);
    }
}

void goToExerciceTwo(void)
{
    node* root = createNode('+');
    root->left = createNode('*');
    root->right = createNode('/');
    root->left->left = createNode('2');
    root->left->right = createNode('-');
    root->left->right->left = createNode('7');
    root->left->right->right = createNode('1');
    root->right->left = createNode('+');
    root->right->left->left = createNode('6');
    root->right->left->right = createNode('8');
    root->right->right = createNode('2');

    int iExpressionEvaluated = evaluateExpression(root);
    printf("\nThe expression evaluated is : %d",iExpressionEvaluated);
}