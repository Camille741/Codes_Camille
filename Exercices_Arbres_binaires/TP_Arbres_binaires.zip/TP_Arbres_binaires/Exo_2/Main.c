#include"Library.h" 



int main() {
    Node* root = createNode('+');
    root->left = createNode('*');
    root->right = createNode('/');

    root->left->left = createNode('2');
    root->left->right = createNode('-');

    root->left->right->left = createNode('1');
    root->left->right->right = createNode('5');

    root->right->left = createNode('+');
    root->right->right = createNode('2');

    root->right->left->left = createNode('6');
    root->right->left->right = createNode('8');

    printf("Result of expression: %d\n", evaluateExpression(root));

    return 0;
}