#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Node {
    char data;
    struct Node* left;
    struct Node* right;
} Node;


Node* createNode(char data);
bool isOperator(char c);
int evaluateExpression(Node* root);