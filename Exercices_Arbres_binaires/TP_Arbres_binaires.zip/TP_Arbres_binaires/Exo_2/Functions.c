#include"Library.h"


Node* createNode(char data)
{
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

bool isOperator(char c)
{
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

int evaluateExpression(Node* root)
{
    if (root == NULL) {
        return 0;
    }
    if (!isOperator(root->data))
    {
        return root->data - '0'; // Si c'est une valeur, retourne sa valeur numérique
    }
    int leftValue = evaluateExpression(root->left);
    int rightValue = evaluateExpression(root->right);

    switch (root->data) {
        case '+':
            return leftValue + rightValue;
        case '-':
            return leftValue - rightValue;
        case '*':
            return leftValue * rightValue;
        case '/':
            if (rightValue != 0)
            {
                return leftValue / rightValue;
            } else
            {
                printf("Division by zero error!\n");
                return 0;
            }
        default:
            printf("Invalid operator!\n");
            return 0;
    }
}
