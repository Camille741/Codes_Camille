Vous trouverez dans ce code une version de notre projet C sans SDL avec 
un affichage se faisant uniquement dans le terminal. 

Vous recevrez d'ici peu un mail avec une version SDL de notre projet. 

Nous vous remercions de votre compréhension.

