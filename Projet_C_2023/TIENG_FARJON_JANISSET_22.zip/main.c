#include "Library.h"


int main() 
{


//----------------------------------------------------------------------------------------
//SDL


/*
   SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS);

   int statut = EXIT_FAILURE;

   SDL_Event event;
SDL_bool quit = SDL_FALSE;





//initialisation SDL
       if(0 != SDL_Init(SDL_INIT_VIDEO))
	   {
		fprintf(stderr, "Erreur SDL_Init : %s", SDL_GetError());
        goto Quit;
	   }
    return EXIT_SUCCESS;

//creation d'une fenetre

SDL_Window *menu = NULL;

	menu = SDL_CreateWindow("menu", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,640, 480, SDL_WINDOW_SHOWN);

//verif si fenetre s'est bien generer
    if(NULL == menu)
    {
        fprintf(stderr, "Erreur SDL_CreateWindow : %s", SDL_GetError());
        goto Quit;
    }

	SDL_SetWindowFullscreen(menu, SDL_WINDOW_FULLSCREEN_DESKTOP);


////creation du rendu
//
//SDL_Renderer *renderer = NULL;
//
//renderer = SDL_CreateRenderer(menu, -1, SDL_RENDERER_ACCELERATED);
//
////verif si rendu s'est bien generé
//    if(NULL == renderer)
//    {
//        fprintf(stderr, "Erreur SDL_CreateRenderer : %s", SDL_GetError());
//        goto Quit;
//    }
//
//dessiner dans le rendu 1

SDL_Rect jouer;

jouer.x = 25;
jouer.y = 25;
jouer.h =  25;
jouer.w = 25;



SDL_Point click_mouse;
click_mouse.x = 0;
click_mouse.y = 0;

//SDL_RenderDrawRect(renderer,  &jouer);


//creation texture sur une fenetre
//
//SDL_Texture *texture = NULL;
//
//texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET, 200, 200);
//
////verif si texture s'est bien generé
//    if(NULL == texture)
//    {
//        fprintf(stderr, "Erreur SDL_CreateTexture : %s", SDL_GetError());
//        goto Quit;
//    }





////image de fond
//SDL_Surface *tmp = NULL; 
//tmp = SDL_LoadBMP("path");
//texture = SDL_CreateTextureFromSurface(renderer, tmp);
//SDL_FreeSurface(tmp); // On libère la surface, on n’en a plus besoin 
////Verif si image bien chargé
//{
//    fprintf(stderr, "Erreur SDL_CreateTextureFromSurface : %s", SDL_GetError());
//    goto Quit;
//}
//
//texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, 
//                            SDL_TEXTUREACCESS_TARGET, tmp->w, tmp->h);
//SDL_SetRenderTarget(renderer, texture);
//SDL_RenderCopy(renderer, texture, NULL, NULL); 
//SDL_DestroyTexture(texture);
//SDL_FreeSurface(tmp);
//SDL_SetRenderTarget(renderer, NULL);
//SDL_Delay(30000);




//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------boucle principale---------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



while(!quit)
{
    SDL_WaitEvent(&event);
    if(event.type == SDL_QUIT)
        goto Quit;
    if(event.type == SDL_MOUSEBUTTONDOWN)
	SDL_GetMouseState(&click_mouse.x,&click_mouse.y);
        printf("cliqué a x =%d,  y =%d", click_mouse.x, click_mouse.y);
}   


///Quit in case of error

	Quit:
	//if(NULL != texture)
    //SDL_DestroyTexture(texture);
    //if(NULL != renderer)
	//SDL_DestroyRenderer(renderer);
    if(NULL != menu)
        SDL_DestroyWindow(menu);
    SDL_Quit();
    return statut;



*/


	Menu();
    return 0;
}