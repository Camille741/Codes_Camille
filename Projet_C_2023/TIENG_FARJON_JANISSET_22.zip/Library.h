#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include<string.h>


/* 

----------------------------------- Structures -----------------------------------
*/


typedef struct Node 
{
     int key; // number of bees into the node
     int key_max; // maximum number of bees into the node
     int number; //id number of the node in the graph
        
}Node;

typedef struct Edge
{
    Node *source;
    Node *destination;
    int weight;
 
}Edge;

typedef struct Graph
{
    int numNodes;
    int numEdges;
    Node **nodes;
    Edge **edges;

}Graph;




/*
- Bee structure -

    - Class
    - Age
    - Pollen


*/
typedef struct Larva
{
    time_t timestamp;
    double developementTime;
    time_t developmentStartTime;
}Larva;


typedef struct Bee
{
    int age;  // age of the bee
    int pollen; // level of pollen carried by the bee
    char Class; // role of the bee in the hive
    Node *position;

}Bee;


typedef struct Hive
{
        int honey_stock; // grams
        int larva; //  nb larva
        int royal_jelly; // grams
        float temperature; // °C
        int number_of_bees; // cqfd
        int working_bees; 
        int defender_bees;
        int outsider_bees;
        float health; // "health point" of hive
        Graph *graph;
        Bee *current;
        Larva *larvae;

}Hive;










/*
- Queen structure -

    - Age
    - Hunger
*/

typedef struct 

{
    int age; // age of the queen
    bool hunger; // level of hunger of the queen
    int sinceLastMeal; // numbers of days since last time the queen was nourished

}Queen;
/*





- Environement -

    - Hornet (bool)
    - Storm (bool)
    - Human (bool)
    - Covid (bool)
    - Season
    - Timer

*/

typedef struct 

{
    bool hornet; // event : is a hornet here (1) or not (0)
    bool storm;  // event : is a storm here (1) or not (0)
    bool human; // event : is a human here (1) or not (0)
    bool covid; // event : is covid here (1) or not (0)
    int season; // indicate the current season
    float timer; // initialization of a chronometer
    time_t start_timer; // start of the timer, functions associated : "StartChronometer" and "getElapsedTime" in the time.h library

}Environment;




/*

- Ressources (renamed Flower )-

    - Lavender
    - Sunflower
    - Lily
    - Dandelion

    */
typedef struct  
{
    char name[25]; //indicate the name of the flower
    int pollen_number; // indicate the quantity of pollen available on a type of flower
    int flower_number; // indicate the number of a type of flower around the hive
    float distance_to_hive; // indicate the average distance between a type of flower and the hive (in meter)

}Flower;



/*



- Hive -
    
    - Honey stock
    - Larva
    - Royal jelly
    - Temperature
    - Number of bees
    - Health

*/


void clear_screen();
void Menu();

Node *createNode(int key, int key_max);
Edge *createEdge(Node *source, Node *destination, int weight);
void addNodeToGraph(Graph *graph, Node *node, int index);
void addEdgeToGraph(Graph *graph, Edge *edge, int index);
Graph *createHive();
void printNode(Node *node);
void printEdge(Edge *edge);
void printGraph(Graph *graph);
void printHive (Hive *H);
void PrintNodeContent(Graph *G, Node *N);

Bee *Create_Bee(Hive*H);
void Moving_Bee(Graph *G, Node *Source, Node *Destination, Bee* B);
void Bee_Death(Hive *H, time_t start); 
void Queen_Reproduction(Queen *queen, Hive*H, time_t start, Bee*feeder);
void Working_bee(Bee*B, Hive *H);
char* getRandomFlowerName();
void displayFlowers();
void Outsider_bee(Bee*B, Hive*H);
void Royal_Jelly(Hive *H);
void EnvironmentImpact(Hive *H);

double getElapsedTime(time_t start);
void updateAndDisplayTime(time_t start, Hive* H);
void Start_Init();
void feedqueen(Queen *queen);