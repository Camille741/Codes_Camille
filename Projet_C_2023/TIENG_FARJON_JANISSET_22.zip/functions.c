    #include"Library.h"


    time_t globalTime; 
    int number_flowers;
    #define NUM_ROLES 3
    #define MAX_FLOWERS 10

    // 3 roles for bees:
    // Working   : get the pollen from outsiders and transform them in honey
    // Outsiders : Get the pollen from outside the hive
    // Defenders : Defend the hive 

    //------------------------------------------------------------
    //                  M   E   N   U
    //------------------------------------------------------------

    void clear_screen()
    {
        // Clear screen for Windows
        #ifdef _WIN32
            system("cls");
        // Clear screen for Unix-based systems
        #else
            system("clear");
        #endif
    }

    void Menu()
    {
        clear_screen();


        printf("▀██▀  ▀██▀  ██                      ▀██    ██▀ \n");                                                 
        printf(" ██    ██  ▄▄▄  ▄▄▄▄ ▄▄▄   ▄▄▄▄      ███  ███   ▄▄▄▄   ▄▄ ▄▄▄    ▄▄▄▄     ▄▄▄ ▄   ▄▄▄▄  ▄▄▄ ▄▄\n");  
        printf(" ██▀▀▀▀██   ██   ▀█▄  █  ▄█▄▄▄██     █▀█▄▄▀██  ▀▀ ▄██   ██  ██  ▀▀ ▄██   ██ ██  ▄█▄▄▄██  ██▀ ▀▀ \n");
        printf(" ██    ██   ██    ▀█▄█   ██          █ ▀█▀ ██  ▄█▀ ██   ██  ██  ▄█▀ ██    █▀▀   ██       ██     \n");
        printf("▄██▄  ▄██▄ ▄██▄    ▀█     ▀█▄▄▄▀    ▄█▄ █ ▄██▄ ▀█▄▄▀█▀ ▄██▄ ██▄ ▀█▄▄▀█▀  ▀████▄  ▀█▄▄▄▀ ▄██▄    \n");
        printf("                                                                        ▄█▄▄▄▄▀                 \n");
                                                                                                        


        printf("Press Enter to start.\n");
        
        int enterKey = getchar();


        
        if (enterKey == '\n') 
        {
            printf("Enter key pressed!\n");
            sleep(2);
            clear_screen();
            Start_Init();
        }
        else
        {
            printf("Another key was pressed.\n");
            sleep(1);
            clear_screen();
            Menu();
        }
    }



    //------------------------------------------------------------
    //                  G   R   A   P   H
    //------------------------------------------------------------


    Node *createNode(int key, int key_max)
    {
        Node *newNode = (Node *)malloc(sizeof(Node));
        newNode->key = key;
        newNode->key_max = key_max;
        newNode->number = 0;
        return newNode;
    }

    Edge *createEdge(Node *Source, Node *Destination, int weight)
    {
        Edge *newEdge = (Edge *)malloc(sizeof(Edge));
        newEdge->source = Source;
        newEdge->destination = Destination;
        newEdge->weight = weight;
        return newEdge;
    }

    void addNodeToGraph(Graph *graph, Node *node, int index)
    {
        graph->nodes[index] = node;
        node->number = index;
    }

    void addEdgeToGraph(Graph *graph, Edge *edge, int index) 
    {
        graph->edges[index] = edge;
    }

    Graph *createHive() // alternative : int creatieHive(int numbernode, int numberedge) 
    {
        Graph *graph = (Graph *)malloc(sizeof(Graph));
        graph->numNodes = 5;
        graph->numEdges = 14;
        graph->nodes = (Node **)malloc(5 * sizeof(Node *));
        graph->edges = (Edge **)malloc(14 * sizeof(Edge *));

    
        Node *Entry = createNode(0, 2000); // there are 2000 bee at the begining of the program
        Node *HoneyStock = createNode(0, 250);
        Node *Incubators = createNode(0, 378);
        Node *RoyalJellyStock = createNode(0, 44);
        Node *QueensRoom = createNode(0, 54);
        

    

        Edge *edge1 = createEdge(Entry, HoneyStock, 5); //Path between entry and honey stock
        Edge *edge2 = createEdge(Entry, Incubators, 7);// Path between entry and incubators
        Edge *edge3 = createEdge(Entry, RoyalJellyStock, 7);//Path between entry and royal jelly stock
        Edge *edge4 = createEdge(HoneyStock, RoyalJellyStock, 7);//Path between honey stock and royak jelly stock
        Edge *edge5 = createEdge(RoyalJellyStock, Incubators, 7);//Path between royal jelly and queen's romm
        Edge *edge6 = createEdge(Incubators, QueensRoom, 7);//Path between incubators and royal jelly
        Edge *edge7 = createEdge(RoyalJellyStock, QueensRoom, 7);// Path between entry and queen's room
        Edge *edge8 = createEdge(HoneyStock, Entry, 5); // Same but different source / destination
        Edge *edge9 = createEdge(Incubators, Entry, 7);
        Edge *edge10 = createEdge(RoyalJellyStock, Entry, 7);
        Edge *edge11= createEdge(RoyalJellyStock, HoneyStock, 7);
        Edge *edge12= createEdge(Incubators, RoyalJellyStock, 7);
        Edge *edge13= createEdge(QueensRoom, Incubators, 7);
        Edge *edge14= createEdge(QueensRoom, RoyalJellyStock, 7);
        

        // adding nodes and vertices in the graph

        addNodeToGraph(graph, Entry, 0); // room with index 0
        addNodeToGraph(graph, HoneyStock, 1);
        addNodeToGraph(graph, Incubators, 2);
        addNodeToGraph(graph, RoyalJellyStock, 3);
        addNodeToGraph(graph, QueensRoom, 4);

        addEdgeToGraph(graph, edge1, 0); //edge with index 0
        addEdgeToGraph(graph, edge2, 1);
        addEdgeToGraph(graph, edge3, 2);
        addEdgeToGraph(graph, edge4, 3);
        addEdgeToGraph(graph, edge5, 4);
        addEdgeToGraph(graph, edge6, 5);
        addEdgeToGraph(graph, edge7, 6);
        addEdgeToGraph(graph, edge8, 7);
        addEdgeToGraph(graph, edge9, 8);
        addEdgeToGraph(graph, edge10,9);
        addEdgeToGraph(graph, edge11, 10);
        addEdgeToGraph(graph, edge12, 11);
        addEdgeToGraph(graph, edge13, 12);
        addEdgeToGraph(graph, edge14, 13);


        return graph;
    }





    void printNode(Node *node)
    {
        printf("Node %d has %d max bees\n", node->number,node->key);
    }

    void printEdge(Edge *edge)
    {
        printf("Edge from Node %d to Node %d with weight %d\n", edge->source->number, edge->destination->number, edge->weight);
    
    }

    void printGraph(Graph *graph)
    {
        printf("Graph with %d nodes and %d edges:\n", graph->numNodes, graph->numEdges);

        printf("Nodes:\n");
        for (int i = 0; i < graph->numNodes; i++) {
            printf(" ");
            printNode(graph->nodes[i]);
        }

        printf("Edges:\n");
        for (int i = 0; i < graph->numEdges; i++) {
            printf(" ");
            printEdge(graph->edges[i]);
        }
    }

    void printHive (Hive *H)
    {
        printf("The hive status is:\n");
        printf("Honey stock : %d\n", H->honey_stock);
        printf("Larvaes : %d\n", H->larva);
        printf("Royal jelly stock : %d\n", H->royal_jelly);
        printf("Temperature : %.2f °C\n", H->temperature);
        printf("Bees: %d\n", H->number_of_bees);
        printf("Working bees: %d\n", H->working_bees);
        printf("Defender bees: %d\n", H->defender_bees);
        printf("Outsider bees: %d\n", H->outsider_bees);


        printf("Health : %.1f %%\n", H->health);
        printf("Total number of flowers : %d\n", number_flowers);
        //printGraph(H->graph);
    }

    void PrintNodeContent(Graph *G, Node *N)
    {

        for (int i = 0; i < G->numNodes; i++) 
        {
            if (G->nodes[i]->key== N->key)
            {
                N = G->nodes[i];
                break;
            }
        }

        if (N != NULL)
        {
            printf("Number of bees in the node is %d\n", N->key);
        } 
        else
        {
            printf("Can't find Node\n");
        }
    }





    //------------------------------------------------------------
    //                  T   I   M   E
    //------------------------------------------------------------


    double getElapsedTime(time_t start) 
    {
        return difftime(time(NULL), start);
    }


    void updateAndDisplayTime(time_t start, Hive *H)
    {
        double elapsedTime = getElapsedTime(start);

        // Convert elapsed time to days, weeks, months, and years based on your simulation time scale
        int days = (int)(elapsedTime / 1);  // Assuming 1 second is a day
        int weeks = days / 7;
        int months = weeks / 4;  // Assuming 30 days in a month
        int years = days / 365;  // Assuming 365 days in a year
        int season = (months / 3) % 4;

        // Display the results

        printf("Elapsed Time: %.2f seconds\n", elapsedTime);
        printf("Days: %d, Weeks: %d, Months: %d, Years: %d\n", days, weeks, months, years);
        
            switch (season) {
            case 0:
                printf("We are now in Spring\n");
                if(H->temperature<22)
                {
                H->temperature = H->temperature + 3;
                }
                break;
            case 1:
                printf("We are now in Summer\n");
                if(H->temperature < 25)
                H->temperature = H->temperature + 7;
                break;
            case 2:
                printf("We are now in Autumn\n");
                if(H->temperature>15)
                H->temperature = H->temperature - 7;
                break;
            case 3:
                printf("Winter is coming...\n");
                if(H->temperature>6)
                H->temperature = H->temperature - 3;
                break;
            default:
                printf("Invalid season\n");
                break;
        }    
    }

    //------------------------------------------------------------
    //                         B   E   E 
    //------------------------------------------------------------
    Bee *Create_Bee(Hive *H)
    {
        Bee *B = malloc(sizeof(*B));
        B->age=0;
        B->pollen=0;
        B->Class ='0';
        B->position= NULL;
        

        int randomRole = rand() % NUM_ROLES; // Generate a random number between 0 and NUM_ROLES - 1
        if (randomRole == 0)
        {
        
        B->Class ='W';
        H->working_bees++;
        H->number_of_bees++;
        Working_bee(B,H); // Bee is a working bee
        return B;
        
        } 
        if (randomRole == 1)
        {
            B->Class = 'O'; // O for outsiders
            H->outsider_bees++;
            H->number_of_bees++;
        return B;
            
        }
        else 
        {
            B->Class = 'D';// 'D' for Defenders bee
            H->defender_bees++;
            H->number_of_bees++;
        return B;
            
        }
    }


    void Bee_Death(Hive *H, time_t start)
    {
        int elapsedTime = getElapsedTime(start);

        if (elapsedTime % 3 == 0)
        {
            int randomRole = rand() % NUM_ROLES;

            if (randomRole == 0 && H->working_bees > 0)
            {
                H->working_bees--;
                H->number_of_bees--;
            }
            else if (randomRole == 1 && H->outsider_bees > 0)
            {
                H->outsider_bees--;
                H->number_of_bees--;
            }
            else if (randomRole == 2 && H->defender_bees > 0)
            {
                H->defender_bees--;
                H->number_of_bees--;
            }

            
            printf("A bee died from old age\n");
        }
    }


    void Moving_Bee(Graph *G, Node *Source, Node *Destination, Bee* B) 
    {


    //Research of source and destination nodes in the graph


        for (int i = 0; i < G->numNodes; i++) 
        {
            if (G->nodes[i]->number == Source->number) 
            {
                Source = G->nodes[i];
            }

            if (G->nodes[i]->number == Destination->number) 
            {
                Destination = G->nodes[i];
            }
        }

        // Verification if the source and destination nodes are existing

        if (Source == NULL || Destination == NULL)
        {
            printf("Cannot find source and/or destination node.\n");
            return;
        }

        // Movement of the bee
        if (Destination->key < Destination->key_max) // If there is room in destination
        {
            if(Destination->key < Destination->key_max)
            {
                Source->number--; // Suppression of a bee
                Destination->number++; // Adding a bee

                printf("Bees went from node %d to node %d\n", Source->number, Destination->number);
            }
            else
            {
                printf("Bee's moving impossible\n");
            }

                // PrintNodeContent(G,Destination);
        } 
        else
        {
            printf("Bee's moving impossible\n");
        }
    } 




    void Queen_Reproduction(Queen *queen, Hive *H, time_t start, Bee*feeder)
    {

        int elapsedTime = getElapsedTime(start);    
        printf("\n");

        if(elapsedTime %4 == 0 && H->graph->nodes[4]->key <= H->graph->nodes[4]->key_max) 
        {             
            Moving_Bee(H->graph, H->graph->nodes[3], H->graph->nodes[4], feeder);
                
                int larvaeProduced = queen->hunger ? 10 : 20; // if queen is hungry only 10 larvaes produced
                
                H->larvae =realloc(H->larvae, (H->larva + larvaeProduced) * sizeof(Larva));
                
                for(int i = H->larva; i < H->larva + larvaeProduced; i++)
                {
                    H->larvae[i].timestamp = start;
                    H->larvae[i].developementTime = 5.0;
                }

                H->larva += larvaeProduced;
                
                printf("%d new larvaes have been put in the hatching room\n", larvaeProduced);
                                
            
        }


    }


    void Hatching(Hive *H, time_t start)
    {
        int elapsedTime = getElapsedTime(start);

        if (elapsedTime % 10 == 0 && H->larva > 0)
        {
            int numhatched = 0;
            int i = 0;

            while (i < H->larva && numhatched < 40) // You can adjust the number (30) based on your desired hatching amount
            {
                Larva *larva = &H->larvae[i];
                double developmentTime = getElapsedTime(larva->timestamp);
                double requiredDevelopmentTime = larva->developementTime;

                if (developmentTime >= requiredDevelopmentTime) // larva is ready to hatch
                {
                    H->larva--;
                    Create_Bee(H);
                    numhatched++;

                    // Remove the hatched larva from the list
                    if (i < H->larva - 1)
                    {
                        H->larvae[i] = H->larvae[H->larva - 1];
                    }

            
                }
                else
                {
                    i++;
                }
            }

            printf("%d larvae hatched successfully\n", numhatched);

        }
    }




    void Working_bee(Bee *B,Hive *H)
    {
        int elapsedTime = getElapsedTime(globalTime);
            if (elapsedTime % 1 == 0)
            {
            //Moving_Bee(H->graph, H->graph->nodes[0], H->graph->nodes[1], B);

        
            H->honey_stock= H->honey_stock+H->working_bees*10;
            

            //Moving_Bee(H->graph, H->graph->nodes[1], H->graph->nodes[0], B);
            }
        
    }

    char* getRandomFlowerName()
    {
        char* flowerNames[] = {"Lily", "Dandelion", "Sunflower", "Lavender"}; 
        int numNames = 3; // Nombre total de noms de fleurs disponibles

        int randomIndex = rand() % numNames;
        return flowerNames[randomIndex];
    }






    void displayFlowers(Flower* flowers, int numFlowers)
    {
        // Déclarez des variables pour les totaux du pollen et du nombre de fleurs
        int totalPollen = 0;
        int totalFlowers = 0;

        for (int i = 0; i < numFlowers; ++i)
        {
            // Ajoutez le pollen et le nombre de fleurs actuels aux totaux
            totalPollen += flowers[i].pollen_number;
            totalFlowers += flowers[i].flower_number;
        }

        // Affichez les totaux à la fin de la boucle
        printf("\nTotal du pollen de toutes les fleurs : %d mg\n", totalPollen);
        printf("Total du nombre de fleurs : %d\n", totalFlowers);
    }

    void generateFlowers() 
    {
        Flower flowers[MAX_FLOWERS];
        int numGeneratedFlowers = 10;
        int elapsedTime = getElapsedTime(globalTime);

        if(elapsedTime % 30 ==0)
        {
        for (int i = 0; i < numGeneratedFlowers; ++i)
        {
            strcpy(flowers[i].name, getRandomFlowerName());
            flowers[i].pollen_number = rand() % 1000; // Nombre aléatoire de pollen (entre 0 et 999)
            flowers[i].flower_number = rand() % 100; // Nombre aléatoire de fleurs autour de la ruche (entre 0 et 99)
            flowers[i].distance_to_hive = (float)(rand() % 1000) / 10; // Distance aléatoire jusqu'à la ruche (entre 0.0 et 99.9)
            number_flowers++;
        }
        }

       // displayFlowers(flowers, numGeneratedFlowers);
    }


    void Royal_Jelly(Hive *H)
    {
        int elapsedTime = getElapsedTime(globalTime);
        if (elapsedTime % 5 == 0 && H->honey_stock != 0)
        {
            H->honey_stock= H->honey_stock - 100;
            H->royal_jelly++;
        }

    }


    void EnvironmentImpact(Hive *H)
    {
        srand(time(NULL));

        
        Environment *E = malloc(sizeof(*E));

        int elapsedTime = getElapsedTime(globalTime);

        if (elapsedTime >= 20 && rand() % 100 < 10) 
        {
            E->human = true;   // Human Event
            printf("Humans came to the hive.\n");

            if(H->defender_bees>20)
            {
                // Removal of 50 % honey stock
                H->honey_stock = H->honey_stock - (50*H->honey_stock)/100; // could also be H->honey_stock = H->honey_stock / 2
                
                //Death of 10 bees

                for(int i=0; i<10;i++)
                {
                int randomRole = rand() % NUM_ROLES;
                if (randomRole == 0 && H->working_bees > 0)
                {
                H->working_bees--;
                }
                else if (randomRole == 1 && H->outsider_bees > 0)
                {
                H->outsider_bees--;
                }
                else if (randomRole == 2 && H->defender_bees > 0)
                {
                H->defender_bees--;
                }
                H->number_of_bees--;
                }
                printf("Removal of 50 percents of the honey stock.\n");
                printf("Death of 10 bees.\n");

            }

            else
            {
                // Removal of 80% honey stock
                H->honey_stock=H->honey_stock - (80*H->honey_stock)/100;
                
                //Death of 75 random bees

                for(int i=0; i<20;i++)
                {
                int randomRole = rand() % NUM_ROLES;
                if (randomRole == 0 && H->working_bees > 0)
                {
                H->working_bees--;
                }
                else if (randomRole == 1 && H->outsider_bees > 0)
                {
                H->outsider_bees--;
                }
                else if (randomRole == 2 && H->defender_bees > 0)
                {
                H->defender_bees--;
                }
                H->number_of_bees--;
                }
                printf("Removal of 80 percents of the honey stock.\n");
                printf("Death of 20 bees.\n");
            }
            

        }

        else if (elapsedTime >= 20 && rand() % 100 < 10) 
        {
            E->storm = true; // Storm Event
            printf("A storm is coming !\n");

            H->health = H->health-20;

            for (int j=0;j<10;j++)
            {
                if(H->outsider_bees>0)
                {
                H->outsider_bees--;
                }
                H->number_of_bees--;
            }
            printf("Hive health - 20\n");
            printf("Death of 10 bees.\n");
        }


        else if (elapsedTime >= 20 && rand() % 100 < 7) 
        {
            E->hornet = true;
            printf("You're being attacked by hornets!\n");

            if(H->defender_bees<20)
            {
                // Removal of 50% Hive health
                H->health=H->health - (50*H->health)/100;
                
                //Death of 30 bees

                for(int i=0; i<30;i++)
                {
                int randomRole = rand() % NUM_ROLES;
                if (randomRole == 0 && H->working_bees > 0)
                {
                H->working_bees--;
                }
                else if (randomRole == 1 && H->outsider_bees > 0)
                {
                H->outsider_bees--;
                }
                else if (randomRole == 2 && H->defender_bees > 0)
                {
                H->defender_bees--;
                }
                H->number_of_bees--;
                }
                printf("Removal of 50 percents of the hive's health\n");
                printf("Death of 30 bees.\n");

            }
            else
            {
                // Removal of 80% health
                H->health=H->health - (80*H->health)/100;
                
                //Death of 75 random bees

                for(int i=0; i<75;i++)
                {
                int randomRole = rand() % NUM_ROLES;
                if (randomRole == 0 && H->working_bees > 0)
                {
                H->working_bees--;
                }
                else if (randomRole == 1 && H->outsider_bees > 0)
                {
                H->outsider_bees--;
                }
                else if (randomRole == 2 && H->defender_bees > 0)
                {
                H->defender_bees--;
                }
                H->number_of_bees--;
                }
                printf("Removal of 80 percents of the hive's health\n");
                printf("Death of 75 bees.\n");
            }

        }
        else if (elapsedTime >= 20 && rand() % 100 < 5) 
        {
            E->covid = true;

            printf("The COVID-19 is striking humans!\n");
            H->health = 100;
            H->honey_stock = H->honey_stock*10;
            printf("Hive healed completely.\n");
            printf("Honey stock multiplied by 10.\n");
        } 

    }

    void feedqueen(Queen *queen)
    {
        queen->sinceLastMeal = 0;
    }




    //------------------------------------------------------------
    //                  S   T   A   R   T
    //------------------------------------------------------------

    void Start_Init()
    {


        Graph *G = createHive();
        Hive *H =malloc(sizeof(*H));
        H->graph=G;
        H->honey_stock=0;
        H->larva=0;
        H->royal_jelly=0;
        H->temperature = 21.5;
        H->number_of_bees = 0;
        H->health=100;

        Queen * Q = malloc(sizeof(*Q));
        Q->age=1;
        Q->hunger = true;

        Bee*feeder = Create_Bee(H);


        for(int i=0;i<50;i++)
        {
            Create_Bee(H);
        }
        


        time_t start = time(NULL);  // Record the start time
        globalTime = start; 


        while (1) 
        { // like a while(true)

    
            updateAndDisplayTime(start, H);
            printf("\n\n\n");
            Queen_Reproduction(Q,H,start,feeder);
            Bee_Death(H,start);
            Working_bee(H->current,H);
            Hatching(H,start);
            EnvironmentImpact(H);
            Royal_Jelly(H);
            printf("\n\n\n");
            printHive(H);
            generateFlowers();
            sleep(1); // REMINDER : NEVER GO UNDER 1 SECOND
            Q->sinceLastMeal++;
            if(Q->sinceLastMeal >= 2)
            {
                Q->hunger = true; // queen is hungry (shouldn't happen)
                printf("The queen is hungry !\n");
                sleep(1);
                feedqueen(Q);
                printf("The queen has been nourished\n");
                sleep(1);
            }
            else
            {
                Q->hunger = false; // queen isn't hungry (normal)
                Q->sinceLastMeal = 0;
            }

            //random_event(H, Q);
            if(H->number_of_bees <= 0 || H->honey_stock <= 0 || H->temperature <= 0 || H->health <= 0)
            {
                clear_screen();
                printf("GAME OVER / END OF SIMULATION\n");
                sleep(5);
                exit(-1);
            }
            clear_screen();
            
        }
    }
